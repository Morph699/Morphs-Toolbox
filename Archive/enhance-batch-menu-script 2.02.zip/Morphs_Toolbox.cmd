@echo off
setlocal EnableDelayedExpansion

:: ============================================
:: ADMIN CHECK - Uses fltmc (no flash)
:: ============================================
fltmc >nul 2>&1
if %errorlevel% NEQ 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs -ArgumentList 'am_admin'"
    exit /b
)

:: ============================================
:: INIT - Runs once, sets everything up
:: ============================================
title Morphs Creations Toolbox Console
set "Version=2.02"
color 0A
mode con: cols=115 lines=45
chcp 437 >nul 2>&1

:: ============================================
:: BASE DIRECTORY - Always relative to script
:: ============================================
CD /D "%~dp0"
set "Base_Dir=%~dp0"
set "Src_Dir=C:\Windows\Setup\FilesU"
set "W_Dir=%Base_Dir%EngineToolbox"
set "P_Dir=%W_Dir%\Programs"
set "F_Dir=%W_Dir%\Frameworks"
if not exist "%W_Dir%" mkdir "%W_Dir%" >nul 2>&1
if not exist "%P_Dir%" mkdir "%P_Dir%" >nul 2>&1
if not exist "%F_Dir%" mkdir "%F_Dir%" >nul 2>&1

:: Network check
ping -n 1 8.8.8.8 >nul 2>&1 && (set "NetState=ONLINE" & set "StateCol=0B") || (set "NetState=OFFLINE" & set "StateCol=0C")

:: Architecture check
if exist "%WinDir%\SysWOW64" (set "Arch=x64") else (set "Arch=x86")

:: TLS 1.2 for downloads
set "Fetch=powershell -Command [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest"

:: ============================================
:: WINGET CHECK - Detect if winget is available
:: ============================================
winget --version >nul 2>&1
if %errorlevel% EQU 0 (set "HaveWinget=1") else (set "HaveWinget=0")

:: Animated Logo
cls
color 0A
chcp 65001 >nul
powershell -ExecutionPolicy Bypass -Command "$colors=@('Cyan','Green','Magenta','Yellow','White','DarkCyan'); $logo=@('        ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß','        ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     ','        ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß','        ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß','        ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß',' ','   ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß','  ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     ','  ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß','  ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß','   ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß'); foreach ($line in $logo) { if ($line.Trim().Length -eq 0) { Write-Host ''; continue }; [char[]]$chars = $line.ToCharArray(); foreach ($c in $chars) { if ($c -eq 'ß') { $color = Get-Random -InputObject $colors; Write-Host $c -ForegroundColor $color -NoNewline } else { Write-Host $c -NoNewline } }; Write-Host '' }"
echo.
timeout /t 2 >nul

:MainMenu
set "Page=1"
cls
color %StateCol%
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo         **Morphs Creations** DEPLOYMENT CONSOLE v%Version%    [^^] MODE: %NetState%    [^^] ARCH: %Arch%
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
echo    Standard Programs          Portable Tools 1          Portable Tools 3          Deployment Runtimes
echo  ---------------------      ---------------------     --------------------      -----------------------
echo  [ 1 ] 7-Zip Archiver       [ 14 ] Everything Search  [ 84 ] CrystalDiskInfo    [ 41 ] AdobeAIR Framework
echo  [ 2 ] WinRAR Suite         [ 24 ] Revo Uninst Pro    [ 85 ] oCam Recorder      [ 42 ] Microsoft XNA Build
echo  [ 3 ] WinDirStat Anlz      [ 71 ] WinSetupFromUSB    [ 86 ] WinToUSB Tool      [ 43 ] OpenAL Audio Engine
echo  [ 4 ] PotPlayer Engine     [ 72 ] Rufus Boot         [ 87 ] WinToHDD Tool      [ 44 ] DirectX Legacy (95MB)
echo  [ 5 ] K-Lite Mega (62MB)   [ 73 ] Ventoy Multi       [ 88 ] Driver Booster     [ 45 ] Visual C++ AIO (65MB)
echo  [ 6 ] Wise Disk Cleaner    [ 74 ] Hard Disk Sent     [ 89 ] MiniTool (80MB)    [ 46 ] Nvidia PhysX Legacy
echo  [ 7 ] UltraISO Utility     [ 75 ] Network Tools      [ 90 ] Lacey Downloader   [ 52 ] Java JRE 8 (x32)
echo  [ 8 ] Telegram Desktop     [ 76 ] Anydesk Tool       [ 91 ] WinTools Prem      [ 53 ] Java JRE 8 (x64)
echo  [ 9 ] AIMP Audio Player    [ 77 ] Psiphon Proxy      [ 92 ] AIDA64 Extreme     -----------------------
echo  [ 10 ] Winamp Player       [ 78 ] HWiNFO Portable    [ 93 ] CCleaner Opt          Forensic Suites
echo  [ 11 ] Lantern VPN Proxy   [ 79 ] CPU-Z Hardware     [ 94 ] Freemake (52MB)    -----------------------
echo  [ 12 ] SmadAV Security     [ 80 ] Easy Context       [ 95 ] Recuva Recovery    [ 151 ] EZ Forensic Pack
echo  [ 13 ] UltraViewer Remote  [ 81 ] Win Update Blck    [ 96 ] Drive Snapshot     [ 152 ] NirLauncher (54MB)
echo   ======================    [ 82 ] PatchMyPC          [ 97 ] WinDirStat Port   ==============================
echo      Online Browsers        [ 83 ] RustDesk Remote    [ 98 ] Aomei Part (55MB)    Macro Selection Presets
echo   ----------------------    -----------------------   -----------------------   ------------------------------
echo   [ 56 ] Edge (90MB)           Portable Tools 2       System Optimizations      [ 300 ] Online Browsers Suite
echo   [ 57 ] Chrome (95MB)      -----------------------  -----------------------    [ 350 ] System Runtimes Pack
echo   [ 58 ] Firefox (55MB)     [ 100 ] Deploy Choco      [ 115 ] Toggle Hibern     [ 400 ] Portable Tools Pack 1
echo   [ 59 ] Brave (98MB)       [ 111 ] Native Img View   [ 116 ] Compact OS Eng    [ 450 ] Forensic Suite
echo   [ 60 ] Avast Antivirus    [ 112 ] Safe WinSxS Purge [ 117 ] Inject Ownership  [ 666 ] NUCLEAR DEPLOYMENT
echo   [ 61 ] Discord (85MB)    -----------------------   [ M ] More Optimizations  ------------------------------
echo   [ 62 ] Steam (45MB)
echo  --------------------------
goto :MenuFooter

:MenuPage2
set "Page=2"
cls
color %StateCol%
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo         **Morphs Creations** DEPLOYMENT CONSOLE v%Version% (Page 2/2)    [^^] MODE: %NetState%
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
echo    Office ^& Productivity     Media Production           Developer Tools             Gaming ^& Social
echo  -------------------------- ------------------------  ------------------------  --------------------------
echo  [ 201 ] LibreOffice(340MB) [ 210 ] OBS Studio(130MB) [ 220 ] VS Code (95MB)    [ 230 ] GOG Galaxy (210MB)
echo  [ 202 ] SumatraPDF Port    [ 211 ] Handbrake (25MB)  [ 221 ] Notepad++         [ 231 ] Epic Games (160MB)
echo  [ 203 ] Foxit Reader(90MB) [ 212 ] Audacity (15MB)   [ 222 ] Git for Win(55MB) [ 232 ] Zoom Client (30MB)
echo  [ 204 ] Notepad3 Portable  [ 213 ] VLC Media (42MB)  [ 223 ] Python 3.12       [ 233 ] Skype Desktop
echo  [ 205 ] WPS Office (205MB) [ 214 ] Shotcut (105MB)   [ 224 ] WinMerge Tool     [ 234 ] WhatsApp Desktop
echo  -------------------------- ------------------------  ------------------------  --------------------------
echo     Network ^& Server          Security ^& Privacy       Archive ^& ISO            Advanced Macros
echo  -------------------------- ------------------------  ------------------------  --------------------------
echo  [ 240 ] Wireshark (80MB)   [ 250 ] Malwarebytes(250M)[ 260 ] PowerISO (10MB)   [ 500 ] All Page 2 Media
echo  [ 241 ] Nmap Security      [ 251 ] Bitdefender(15MB) [ 261 ] Rufus (Latest)    [ 510 ] All Page 2 Office
echo  [ 242 ] PuTTY SSH Client   [ 252 ] Kaspersky Tool    [ 262 ] ImgBurn Suite     [ 520 ] All Page 2 Dev
echo  [ 243 ] FileZilla FTP      [ 253 ] GlassWire (75MB)  [ 263 ] AnyBurn Suite     [ 530 ] Full Page 2 Sync
echo  [ 244 ] Advanced IP Scan   [ 254 ] VeraCrypt (35MB)  [ 264 ] BurnAware         [ 666 ] NUCLEAR DEPLOYMENT
echo  -------------------------- ------------------------  ------------------------  --------------------------
goto :MenuFooter

:: ============================================================================
:: SYSTEM OPTIMIZATIONS SUB-MENU
:: ============================================================================
:OptMenu
cls
color %StateCol%
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo         **Morphs Creations** SYSTEM OPTIMIZATIONS MENU    [^^] MODE: %NetState%
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
echo   Core Tweaks                        Context Menu Additions (ENABLE)
echo  ----------------------------------  -------------------------------------------------------
echo  [ 115 ] Toggle Hibernation Off      [ 120 ] Enable CP Desktop Context Menu
echo  [ 116 ] Compact OS Engine           [ 121 ] Enable Personalize Classic
echo  [ 117 ] Inject Take Ownership       [ 122 ] Enable Restart Explorer Context Menu
echo                                      [ 123 ] Enable System Shortcuts
echo                                      [ 124 ] Enable System Tools
echo                                      [ 125 ] Enable Take Ownership Context Menu
echo.
echo   Context Menu Removals (DISABLE/REVERSE)
echo  -------------------------------------------------------
echo  [ 130 ] Disable CP Desktop Context Menu
echo  [ 131 ] Disable Personalize Classic
echo  [ 132 ] Disable Restart Explorer Context Menu
echo  [ 133 ] Disable System Shortcuts
echo  [ 134 ] Disable System Tools
echo  [ 135 ] Disable Take Ownership Context Menu
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo     [ 0 ] Return to Main Menu
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
set /p "mopts=   Selection: "
if /I "%mopts%"=="0"   goto :MainMenu
if /I "%mopts%"==""    goto :OptMenu
set "opts=%mopts%"

set /a "TotalCount=0"
for %%i in (%opts%) do set /a "TotalCount+=1"
set /a "CurrentItem=0"

for %%i in (%opts%) do (
    set /a "CurrentItem+=1"
    cls
    echo.
    echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
    echo     PROCESSING [!CurrentItem!/%TotalCount%]: Option %%i
    echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
    echo.
    call :Opt_%%i
)
cls
color 0B
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo     [+] Done - %TotalCount% task(s) completed. Returning to Optimizations menu...
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
timeout /t 2 >nul
goto :OptMenu

:MenuFooter
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo     [ 0 ] Exit ^| [ N ] Next Page ^| [ B ] Back Page ^| [ M ] More Optimizations ^| [ S ] Save ^| [ L ] Load
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
set /p "opts=   Selection: "
if /I "%opts%"=="0" exit /b
if /I "%opts%"=="N" goto :MenuPage2
if /I "%opts%"=="B" goto :MainMenu
if /I "%opts%"=="M" goto :OptMenu
if /I "%opts%"=="S" goto :SaveProfile
if /I "%opts%"=="L" goto :LoadProfile
if "%opts%"=="" goto :MainMenu

:: Macro Expansion for Presets
if /I "%opts%"=="300"   set "opts=56 57 58 59"
if /I "%opts%"=="350"   set "opts=41 42 43 44 45 46 52 53"
if /I "%opts%"=="400"   set "opts=14 24 71 72 73 74 75 76 77 78 79 80 81 82 83"
if /I "%opts%"=="410"   set "opts=84 85 86 87 88 89 90 91 92 93 94 95 96 97 98"
if /I "%opts%"=="450"   set "opts=151 152"
if /I "%opts%"=="500"   set "opts=210 211 212 213 214"
if /I "%opts%"=="510"   set "opts=201 202 203 204 205"
if /I "%opts%"=="520"   set "opts=220 221 222 223 224"
if /I "%opts%"=="530"   set "opts=201 202 203 204 205 210 211 212 213 214 220 221 222 223 224 230 231 232 233 234 240 241 242 243 244 250 251 252 253 254 260 261 262 263 264"
if /I "%opts%"=="666"   set "opts=1 2 45 56 57 201 210 220 231"

set /a "TotalCount=0"
for %%i in (%opts%) do set /a "TotalCount+=1"
set /a "CurrentItem=0"

:RunSelectionLoop
for %%i in (%opts%) do (
    set /a "CurrentItem+=1"
    cls
    echo.
    echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
    echo     PROCESSING [!CurrentItem!/%TotalCount%]: Option %%i
    echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
    echo.
    call :Opt_%%i
)
cls
color 0B
echo.
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo     [+] Queue finished - %TotalCount% tasks completed. Returning to menu...
echo  ════════════════════════════════════════════════════════════════════════════════════════════════════════════
echo.
timeout /t 2 >nul
goto :MainMenu

:: ============================================================================
:: UTILITY: Extract ZIP files (always extracts to P_Dir)
:: ============================================================================
:UnpackPayload
set "ZipFile=%~1"
set "FolderTarget=%~2"
set "ZipBase=%~3"
if "%ZipBase%"=="" set "ZipBase=%P_Dir%"
if exist "%ZipBase%\%ZipFile%" (
    mkdir "%ZipBase%\%FolderTarget%" 2>nul
    powershell -Command "Expand-Archive -Path '%ZipBase%\%ZipFile%' -DestinationPath '%ZipBase%\%FolderTarget%' -Force"
    if !errorlevel! EQU 0 (
        del /f /q "%ZipBase%\%ZipFile%" 2>nul
        echo     [+] Extracted to %FolderTarget%
    ) else (
        echo     [-] Failed to extract %FolderTarget%
    )
)
goto :EOF

:: ============================================================================
:: UTILITY: Winget install wrapper
::   Usage: call :WingetInstall "Publisher.AppID" "Fallback description"
::   If winget is present  -> uses winget (always fetches latest)
::   If winget is absent   -> calls the :WingetFallback_%~1 label if defined,
::                            otherwise prints a manual-download notice.
:: ============================================================================
:WingetInstall
set "WG_ID=%~1"
set "WG_DESC=%~2"
if "%HaveWinget%"=="1" (
    echo     [winget] Installing latest: %WG_DESC%  [ID: %WG_ID%]
    winget install --id "%WG_ID%" -e --silent --accept-package-agreements --accept-source-agreements
    if !errorlevel! EQU 0 (echo     [+] %WG_DESC% installed via winget) else (echo     [-] winget reported an issue - check above)
) else (
    echo     [!] winget not available - using direct download fallback
    call :WG_Fallback_%WG_ID% 2>nul
    if !errorlevel! NEQ 0 echo     [-] No fallback defined for %WG_ID%
)
goto :EOF

:: ============================================================================
:: UTILITY: GitHub latest release downloader (no version number needed)
::   Usage: call :GHLatest "owner/repo" "asset-pattern" "outfile"
::   Uses GitHub API to resolve the latest release asset URL matching pattern
:: ============================================================================
:GHLatest
set "GH_REPO=%~1"
set "GH_PAT=%~2"
set "GH_OUT=%~3"
echo     [GitHub] Resolving latest release for %GH_REPO% ...
powershell -Command ^
  "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
  "$ProgressPreference='SilentlyContinue';" ^
  "try {" ^
  "  $rel = Invoke-RestMethod 'https://api.github.com/repos/%GH_REPO%/releases/latest';" ^
  "  $asset = $rel.assets | Where-Object { $_.name -match '%GH_PAT%' } | Select-Object -First 1;" ^
  "  if ($asset) { Invoke-WebRequest $asset.browser_download_url -OutFile '%GH_OUT%'; exit 0 }" ^
  "  else { Write-Host '[-] No matching asset found for pattern: %GH_PAT%'; exit 1 }" ^
  "} catch { Write-Host $_.Exception.Message; exit 1 }"
goto :EOF

:: ============================================================================
:: STANDARD PROGRAMS
:: ============================================================================

:Opt_1
echo     [7-Zip] -- winget always installs latest
set "W=03_7z-x64.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
call :WingetInstall "7zip.7zip" "7-Zip"
exit /b

:: Fallback for 7-Zip if no winget
:WG_Fallback_7zip.7zip
:: GitHub always-latest redirect - filename stays stable across versions
!Fetch! "https://www.7-zip.org/a/7z-x64.exe" -OutFile "%P_Dir%\7z-x64.exe" 2>nul
if !errorlevel! NEQ 0 (
    call :GHLatest "ip7z/7-Zip" "x64.exe" "%P_Dir%\7z-x64.exe"
)
if exist "%P_Dir%\7z-x64.exe" (start /wait "" "%P_Dir%\7z-x64.exe" /S & echo     [+] 7-Zip installed) else (echo     [-] Failed)
goto :EOF

:Opt_2
echo     [WinRAR] -- winget always installs latest
set "W=31_winrar.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
call :WingetInstall "RARLab.WinRAR" "WinRAR"
exit /b

:WG_Fallback_RARLab.WinRAR
:: RARLab keeps a stable latest URL
!Fetch! "https://www.rarlab.com/rar/winrar-x64.exe" -OutFile "%P_Dir%\winrar-x64.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\winrar-x64.exe" /S & echo     [+] WinRAR installed) else (echo     [-] Failed)
goto :EOF

:Opt_3
echo     [WinDirStat] -- winget always installs latest
call :WingetInstall "WinDirStat.WinDirStat" "WinDirStat"
exit /b

:WG_Fallback_WinDirStat.WinDirStat
call :GHLatest "windirstat/windirstat" "setup.exe" "%P_Dir%\wds.exe"
if exist "%P_Dir%\wds.exe" (start /wait "" "%P_Dir%\wds.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_4
echo     [PotPlayer] -- winget always installs latest
call :WingetInstall "Daum.PotPlayer" "PotPlayer"
exit /b

:WG_Fallback_Daum.PotPlayer
!Fetch! "https://t1.kakaocdn.net/potplayer/PotPlayer/Version/Latest/PotPlayerSetup64.exe" -OutFile "%P_Dir%\pot.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\pot.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_5
echo     [K-Lite Mega] -- vendor stable URL
set "W=11_K-Lite_Codec_Pack_Mega.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
:: Codecguide publishes a stable redirect URL for the latest Mega pack
!Fetch! "https://files3.codecguide.com/K-Lite_Codec_Pack_Mega.exe" -OutFile "%P_Dir%\klite.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\klite.exe" /verysilent & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_6
echo     [Wise Disk Cleaner] -- winget always installs latest
call :WingetInstall "WiseCleaner.WiseDiskCleaner" "Wise Disk Cleaner"
exit /b

:WG_Fallback_WiseCleaner.WiseDiskCleaner
!Fetch! "https://downloads.wisecleaner.com/soft/WDCSetup.exe" -OutFile "%P_Dir%\wise.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\wise.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_7
echo     [UltraISO] -- direct download
!Fetch! "https://dw.ezbsys.net/uiso9_pe.exe" -OutFile "%P_Dir%\uiso.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\uiso.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_8
echo     [Telegram] -- winget always installs latest
call :WingetInstall "Telegram.TelegramDesktop" "Telegram Desktop"
exit /b

:WG_Fallback_Telegram.TelegramDesktop
:: Telegram publishes a stable latest URL
!Fetch! "https://telegram.org/dl/desktop/win64" -OutFile "%P_Dir%\telegram.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\telegram.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_9
echo     [AIMP] -- winget always installs latest
call :WingetInstall "AIMP.AIMP" "AIMP"
exit /b

:WG_Fallback_AIMP.AIMP
:: AIMP: no stable vanity URL - use GitHub API via pattern
call :GHLatest "aimp-devteam/aimp" "x64.exe" "%P_Dir%\aimp.exe"
if exist "%P_Dir%\aimp.exe" (start /wait "" "%P_Dir%\aimp.exe" /VERYSILENT) else (
    !Fetch! "https://www.aimp.ru/storage/aimp_5.40.2675.exe" -OutFile "%P_Dir%\aimp.exe"
    if !errorlevel! EQU 0 start /wait "" "%P_Dir%\aimp.exe" /VERYSILENT
)
echo     [+] AIMP installed
goto :EOF

:Opt_10
echo     [Winamp] -- winget always installs latest
call :WingetInstall "Radionomy.Winamp" "Winamp"
exit /b

:WG_Fallback_Radionomy.Winamp
!Fetch! "https://download.nullsoft.com/winamp/client/winamp592_10042_full_en-us.exe" -OutFile "%P_Dir%\wa.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\wa.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_11
echo     [Lantern VPN] -- GitHub latest release
call :GHLatest "getlantern/lantern-binaries" "lantern-installer.exe" "%P_Dir%\lantern.exe"
if exist "%P_Dir%\lantern.exe" (start /wait "" "%P_Dir%\lantern.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_12
echo     [SmadAV] -- direct download (vendor URL)
!Fetch! "https://www.smadav.net/download/smadav2025.exe" -OutFile "%P_Dir%\smadav.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\smadav.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_13
echo     [UltraViewer] -- direct download (vendor URL)
!Fetch! "https://dl2.ultraviewer.net/UltraViewer_setup_6.6_en.exe" -OutFile "%P_Dir%\uv.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\uv.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:: ============================================================================
:: PORTABLE TOOLS 1
:: ============================================================================

:Opt_14
echo     [Everything] -- winget always installs latest
call :WingetInstall "voidtools.Everything" "Everything Search"
exit /b

:WG_Fallback_voidtools.Everything
:: voidtools publishes a stable x64 installer URL
!Fetch! "https://www.voidtools.com/Everything-x64-Setup.exe" -OutFile "%P_Dir%\Everything.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\Everything.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_24
echo     [Revo Uninstaller] -- winget always installs latest
call :WingetInstall "RevoUninstaller.RevoUninstaller" "Revo Uninstaller"
exit /b

:WG_Fallback_RevoUninstaller.RevoUninstaller
!Fetch! "https://www.revouninstaller.com/download-free-portable.php" -OutFile "%P_Dir%\revo.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\revo.exe" /verysilent & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_71
echo     [WinSetupFromUSB] -- direct download (vendor URL)
!Fetch! "https://www.winsetupfromusb.com/downloads/WinSetupFromUSB_1.10.exe" -OutFile "%P_Dir%\WinSetupFromUSB.exe"
if !errorlevel! EQU 0 (echo     [+] Ready) else (echo     [-] Failed)
exit /b

:Opt_72
echo     [Rufus] -- GitHub latest release redirect (always latest)
:: GitHub releases/latest/download/ redirects to the newest asset automatically
!Fetch! "https://github.com/pbatard/rufus/releases/latest/download/rufus.exe" -OutFile "%P_Dir%\rufus.exe"
if !errorlevel! EQU 0 (echo     [+] Ready - latest Rufus) else (echo     [-] Failed)
exit /b

:Opt_73
echo     [Ventoy] -- GitHub latest release via API
call :GHLatest "ventoy/Ventoy" "windows.zip" "%P_Dir%\ventoy.zip"
if exist "%P_Dir%\ventoy.zip" (call :UnpackPayload "ventoy.zip" "Ventoy") else (echo     [-] Failed)
exit /b

:Opt_74
echo     [Hard Disk Sentinel] -- vendor portable zip (stable URL)
!Fetch! "https://www.hdsentinel.com/hdsentinel_portable.zip" -OutFile "%P_Dir%\hds.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "hds.zip" "HardDiskSentinel") else (echo     [-] Failed)
exit /b

:Opt_75
echo     [Advanced IP Scanner] -- winget always installs latest
call :WingetInstall "Famatech.AdvancedIPScanner" "Advanced IP Scanner"
exit /b

:WG_Fallback_Famatech.AdvancedIPScanner
!Fetch! "https://download.advanced-ip-scanner.com/Advanced_IP_Scanner_2.5.4594.1.exe" -OutFile "%P_Dir%\ais.exe"
if !errorlevel! EQU 0 (start "" "%P_Dir%\ais.exe" & echo     [+] Launched) else (echo     [-] Failed)
goto :EOF

:Opt_76
echo     [AnyDesk] -- winget always installs latest
call :WingetInstall "AnyDeskSoftwareGmbH.AnyDesk" "AnyDesk"
exit /b

:WG_Fallback_AnyDeskSoftwareGmbH.AnyDesk
:: AnyDesk publishes a stable latest URL
!Fetch! "https://download.anydesk.com/AnyDesk.exe" -OutFile "%P_Dir%\AnyDesk.exe"
if !errorlevel! EQU 0 (echo     [+] Ready) else (echo     [-] Failed)
goto :EOF

:Opt_77
echo     [Psiphon] -- stable vendor URL
!Fetch! "https://psiphon.ca/psiphon3.exe" -OutFile "%P_Dir%\psiphon.exe"
if !errorlevel! EQU 0 (echo     [+] Ready) else (echo     [-] Failed)
exit /b

:Opt_78
echo     [HWiNFO] -- winget always installs latest
call :WingetInstall "REALiX.HWiNFO" "HWiNFO"
exit /b

:WG_Fallback_REALiX.HWiNFO
:: HWiNFO stable portable URL
!Fetch! "https://www.hwinfo.com/portable/hwinfo64.zip" -OutFile "%P_Dir%\hwinfo.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "hwinfo.zip" "HWiNFO") else (echo     [-] Failed)
goto :EOF

:Opt_79
echo     [CPU-Z] -- winget always installs latest
call :WingetInstall "CPUID.CPU-Z" "CPU-Z"
exit /b

:WG_Fallback_CPUID.CPU-Z
:: CPUID publishes a stable portable zip URL
!Fetch! "https://download.cpuid.com/cpu-z/cpu-z_en.zip" -OutFile "%P_Dir%\cpuz.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "cpuz.zip" "CPUZ") else (echo     [-] Failed)
goto :EOF

:Opt_80
echo     [Easy Context Menu] -- direct download (stable vendor URL)
!Fetch! "https://www.sordum.org/files/easy-context-menu/ec_menu.zip" -OutFile "%P_Dir%\ecmenu.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "ecmenu.zip" "EasyContextMenu") else (echo     [-] Failed)
exit /b

:Opt_81
echo     [Windows Update Blocker] -- direct download (stable vendor URL)
!Fetch! "https://www.sordum.org/files/windows-update-blocker/wub.zip" -OutFile "%P_Dir%\wub.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "wub.zip" "WUB") else (echo     [-] Failed)
exit /b

:Opt_82
echo     [PatchMyPC] -- stable vendor URL (always latest)
!Fetch! "https://patchmypc.com/freeupdater/PatchMyPC.exe" -OutFile "%P_Dir%\PatchMyPC.exe"
if !errorlevel! EQU 0 (echo     [+] Ready) else (echo     [-] Failed)
exit /b

:Opt_83
echo     [RustDesk] -- GitHub latest release redirect (always latest)
call :GHLatest "rustdesk/rustdesk" "x86_64.exe$" "%P_Dir%\rustdesk.exe"
if exist "%P_Dir%\rustdesk.exe" (start /wait "" "%P_Dir%\rustdesk.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:: ============================================================================
:: PORTABLE TOOLS 3
:: ============================================================================

:Opt_84
echo     [CrystalDiskInfo] -- winget always installs latest
call :WingetInstall "CrystalDewWorld.CrystalDiskInfo" "CrystalDiskInfo"
exit /b

:WG_Fallback_CrystalDewWorld.CrystalDiskInfo
call :GHLatest "hiyohiyo/CrystalDiskInfo" "Portable.zip" "%P_Dir%\cdi.zip"
if exist "%P_Dir%\cdi.zip" (call :UnpackPayload "cdi.zip" "CrystalDiskInfo") else (echo     [-] Failed)
goto :EOF

:Opt_85
echo     [oCam] -- direct download (vendor URL)
!Fetch! "https://ohsoft.net/data/ocam/ocam_full.exe" -OutFile "%P_Dir%\ocam.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\ocam.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_86
echo     [WinToUSB] -- direct download (vendor URL)
!Fetch! "https://www.easyuefi.com/wintousb/download/WinToUSB_Free.exe" -OutFile "%P_Dir%\wintousb.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\wintousb.exe" /verysilent & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_87
echo     [WinToHDD] -- direct download (vendor URL)
!Fetch! "https://www.easyuefi.com/wintohdd/download/WinToHDD_Free.exe" -OutFile "%P_Dir%\wintohdd.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\wintohdd.exe" /verysilent & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_88
echo     [Driver Booster] -- winget always installs latest
call :WingetInstall "IObit.DriverBooster" "Driver Booster"
exit /b

:WG_Fallback_IObit.DriverBooster
!Fetch! "https://cdn.iobit.com/dl/driver_booster_setup.exe" -OutFile "%P_Dir%\driverbooster.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\driverbooster.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_89
echo     [MiniTool Partition Wizard] -- winget always installs latest
call :WingetInstall "MiniTool.PartitionWizard.Free" "MiniTool Partition Wizard"
exit /b

:WG_Fallback_MiniTool.PartitionWizard.Free
!Fetch! "https://cdn2.minitool.com/?p=pw&a=pw-free-offline" -OutFile "%P_Dir%\minitool.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\minitool.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_90
echo     [Lacey] -- direct download
!Fetch! "https://laceydownload.com/lacey.zip" -OutFile "%P_Dir%\lacey.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "lacey.zip" "Lacey") else (echo     [-] Failed)
exit /b

:Opt_91
echo     [WinTools] -- direct download
!Fetch! "https://www.wintools.net/wintoolsp.zip" -OutFile "%P_Dir%\wintools.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "wintools.zip" "WinTools") else (echo     [-] Failed)
exit /b

:Opt_92
echo     [AIDA64] -- winget always installs latest
call :WingetInstall "FinalWire.AIDA64Extreme" "AIDA64 Extreme"
exit /b

:WG_Fallback_FinalWire.AIDA64Extreme
!Fetch! "https://download.aida64.com/aida64extreme.exe" -OutFile "%P_Dir%\aida64.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\aida64.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_93
echo     [CCleaner] -- winget always installs latest
call :WingetInstall "Piriform.CCleaner" "CCleaner"
exit /b

:WG_Fallback_Piriform.CCleaner
!Fetch! "https://bits.avcdn.net/product/CCLEANER/win/CCSetup.exe" -OutFile "%P_Dir%\ccleaner.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\ccleaner.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_94
echo     [Freemake Video Converter] -- direct download (vendor URL)
!Fetch! "https://www.freemake.com/FreemakeVideoConverter.exe" -OutFile "%P_Dir%\freemake.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\freemake.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_95
echo     [Recuva] -- winget always installs latest
call :WingetInstall "Piriform.Recuva" "Recuva"
exit /b

:WG_Fallback_Piriform.Recuva
!Fetch! "https://bits.avcdn.net/product/RECUVA/win/RCSetup.exe" -OutFile "%P_Dir%\recuva.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\recuva.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_96
echo     [Drive Snapshot] -- direct download (vendor URL)
!Fetch! "https://www.drivesnapshot.de/download/setup.exe" -OutFile "%P_Dir%\drivesnapshot.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\drivesnapshot.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_97
echo     [WinDirStat Portable] -- GitHub latest release via API
call :GHLatest "windirstat/windirstat" "setup.exe" "%P_Dir%\windirstat_port.exe"
if exist "%P_Dir%\windirstat_port.exe" (start /wait "" "%P_Dir%\windirstat_port.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_98
echo     [Aomei Partition Assistant] -- winget always installs latest
call :WingetInstall "AOMEI.PartitionAssistant" "AOMEI Partition Assistant"
exit /b

:WG_Fallback_AOMEI.PartitionAssistant
!Fetch! "https://www2.aomeisoftware.com/download/pa/PAPE_Lite.zip" -OutFile "%P_Dir%\aomei.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "aomei.zip" "Aomei") else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: PORTABLE TOOLS 2
:: ============================================================================

:Opt_100
echo     [Chocolatey] Installing...
powershell -Command "iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))"
echo     [+] Chocolatey installed
exit /b

:Opt_111
echo     [Image Viewer] Downloading...
!Fetch! "https://raw.githubusercontent.com/mcmilk/7-Zip-Scripts/master/MinimalImageViewer.exe" -OutFile "%P_Dir%\ImageViewer.exe"
if !errorlevel! EQU 0 (echo     [+] Ready) else (echo     [-] Failed)
exit /b

:Opt_112
echo     [WinSxS Cleanup] Running DISM...
Dism.exe /online /Cleanup-Image /StartComponentCleanup /ResetBase
echo     [+] Complete
exit /b

:: ============================================================================
:: SYSTEM OPTIMIZATIONS - CORE
:: ============================================================================

:Opt_115
echo     [Hibernation] Toggling off...
powercfg /h off
echo     [+] Hibernation disabled
exit /b

:Opt_116
echo     [Compact OS] Enabling...
compact /compactos:always
echo     [+] Complete
exit /b

:Opt_117
echo     [Take Ownership] Adding to context menu...
(echo Windows Registry Editor Version 5.00
echo.
echo [HKEY_CLASSES_ROOT\*\shell\runas]
echo @="Take Ownership"
echo "HasLUAShield"=""
echo.
echo [HKEY_CLASSES_ROOT\*\shell\runas\command]
echo @="cmd.exe /c takeown /f \"%%1\" ^& icacls \"%%1\" /grant administrators:F"
echo.
echo [HKEY_CLASSES_ROOT\Directory\shell\runas]
echo @="Take Ownership"
echo "HasLUAShield"=""
echo.
echo [HKEY_CLASSES_ROOT\Directory\shell\runas\command]
echo @="cmd.exe /c takeown /f \"%%1\" /r /d y ^& icacls \"%%1\" /grant administrators:F /t") > "%F_Dir%\TakeOwnership.reg"
regedit /s "%F_Dir%\TakeOwnership.reg"
echo     [+] Done
exit /b

:: ============================================================================
:: SYSTEM OPTIMIZATIONS - CONTEXT MENU ENABLE (REG FILES FROM F_Dir)
:: ============================================================================

:Opt_120
echo     [CP Desktop Context Menu] Enabling...
if exist "%F_Dir%\Enable_CP Desktop Context Menu.reg" (
    regedit /s "%F_Dir%\Enable_CP Desktop Context Menu.reg"
    echo     [+] CP Desktop Context Menu enabled
) else (
    echo     [-] REG file not found: %F_Dir%\Enable_CP Desktop Context Menu.reg
)
exit /b

:Opt_121
echo     [Personalize Classic] Enabling...
if exist "%F_Dir%\Enable_Personalize Classic.reg" (
    regedit /s "%F_Dir%\Enable_Personalize Classic.reg"
    echo     [+] Personalize Classic enabled
) else (
    echo     [-] REG file not found: %F_Dir%\Enable_Personalize Classic.reg
)
exit /b

:Opt_122
echo     [Restart Explorer Context Menu] Enabling...
if exist "%F_Dir%\Enable_Restart_Explorer_to_desktop_context_menu.reg" (
    regedit /s "%F_Dir%\Enable_Restart_Explorer_to_desktop_context_menu.reg"
    echo     [+] Restart Explorer Context Menu enabled
) else (
    echo     [-] REG file not found: %F_Dir%\Enable_Restart_Explorer_to_desktop_context_menu.reg
)
exit /b

:Opt_123
echo     [System Shortcuts] Enabling...
if exist "%F_Dir%\Enable_SystemShortcuts.reg" (
    regedit /s "%F_Dir%\Enable_SystemShortcuts.reg"
    echo     [+] System Shortcuts enabled
) else (
    echo     [-] REG file not found: %F_Dir%\Enable_SystemShortcuts.reg
)
exit /b

:Opt_124
echo     [System Tools] Enabling...
if exist "%F_Dir%\Enable_SystemTools.reg" (
    regedit /s "%F_Dir%\Enable_SystemTools.reg"
    echo     [+] System Tools enabled
) else (
    echo     [-] REG file not found: %F_Dir%\Enable_SystemTools.reg
)
exit /b

:Opt_125
echo     [Take Ownership Context Menu] Enabling...
if exist "%F_Dir%\Enable_Take Ownership to Context menu.reg" (
    regedit /s "%F_Dir%\Enable_Take Ownership to Context menu.reg"
    echo     [+] Take Ownership Context Menu enabled
) else (
    echo     [-] REG file not found: %F_Dir%\Enable_Take Ownership to Context menu.reg
)
exit /b

:: ============================================================================
:: SYSTEM OPTIMIZATIONS - CONTEXT MENU DISABLE/REVERSE (REG FILES FROM F_Dir)
:: ============================================================================

:Opt_130
echo     [CP Desktop Context Menu] Disabling...
if exist "%F_Dir%\Disable_CP Desktop Context Menu.reg" (
    regedit /s "%F_Dir%\Disable_CP Desktop Context Menu.reg"
    echo     [+] CP Desktop Context Menu disabled
) else (
    echo     [-] REG file not found: %F_Dir%\Disable_CP Desktop Context Menu.reg
)
exit /b

:Opt_131
echo     [Personalize Classic] Disabling...
if exist "%F_Dir%\Disable_Personalize Classic.reg" (
    regedit /s "%F_Dir%\Disable_Personalize Classic.reg"
    echo     [+] Personalize Classic disabled
) else (
    echo     [-] REG file not found: %F_Dir%\Disable_Personalize Classic.reg
)
exit /b

:Opt_132
echo     [Restart Explorer Context Menu] Disabling...
if exist "%F_Dir%\Disable_Restart_Explorer_to_desktop_context_menu.reg" (
    regedit /s "%F_Dir%\Disable_Restart_Explorer_to_desktop_context_menu.reg"
    echo     [+] Restart Explorer Context Menu disabled
) else (
    echo     [-] REG file not found: %F_Dir%\Disable_Restart_Explorer_to_desktop_context_menu.reg
)
exit /b

:Opt_133
echo     [System Shortcuts] Disabling...
if exist "%F_Dir%\Disable_SystemShortcuts.reg" (
    regedit /s "%F_Dir%\Disable_SystemShortcuts.reg"
    echo     [+] System Shortcuts disabled
) else (
    echo     [-] REG file not found: %F_Dir%\Disable_SystemShortcuts.reg
)
exit /b

:Opt_134
echo     [System Tools] Disabling...
if exist "%F_Dir%\Disable_SystemTools.reg" (
    regedit /s "%F_Dir%\Disable_SystemTools.reg"
    echo     [+] System Tools disabled
) else (
    echo     [-] REG file not found: %F_Dir%\Disable_SystemTools.reg
)
exit /b

:Opt_135
echo     [Take Ownership Context Menu] Disabling...
if exist "%F_Dir%\Disable_Take Ownership to Context menu.reg" (
    regedit /s "%F_Dir%\Disable_Take Ownership to Context menu.reg"
    echo     [+] Take Ownership Context Menu disabled
) else (
    echo     [-] REG file not found: %F_Dir%\Disable_Take Ownership to Context menu.reg
)
exit /b

:: ============================================================================
:: ONLINE BROWSERS
:: ============================================================================

:Opt_56
echo     [Edge] -- winget always installs latest
call :WingetInstall "Microsoft.Edge" "Microsoft Edge"
exit /b

:WG_Fallback_Microsoft.Edge
!Fetch! "https://msedge.sf.dl.delivery.mp.microsoft.com/filestreamingservice/files/MicrosoftEdgeEnterpriseX64.msi" -OutFile "%P_Dir%\edge.msi"
if !errorlevel! EQU 0 (msiexec /i "%P_Dir%\edge.msi" /qn & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_57
echo     [Chrome] -- winget always installs latest
set "W=10_Chrome.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
call :WingetInstall "Google.Chrome" "Google Chrome"
exit /b

:WG_Fallback_Google.Chrome
:: Google Chrome always-latest standalone URL
!Fetch! "https://dl.google.com/chrome/install/ChromeStandaloneSetup64.exe" -OutFile "%P_Dir%\chrome.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\chrome.exe" /silent /install & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_58
echo     [Firefox] -- winget always installs latest
call :WingetInstall "Mozilla.Firefox" "Mozilla Firefox"
exit /b

:WG_Fallback_Mozilla.Firefox
:: Mozilla always-latest URL
!Fetch! "https://download.mozilla.org/?product=firefox-latest-ssl&os=win64&lang=en-US" -OutFile "%P_Dir%\firefox.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\firefox.exe" -ms & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_59
echo     [Brave] -- winget always installs latest
call :WingetInstall "Brave.Brave" "Brave Browser"
exit /b

:WG_Fallback_Brave.Brave
:: GitHub latest redirect - Brave keeps stable asset name
!Fetch! "https://github.com/brave/brave-browser/releases/latest/download/BraveBrowserStandaloneSetup.exe" -OutFile "%P_Dir%\brave.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\brave.exe" /silent /install & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_60
echo     [Avast] -- winget always installs latest
call :WingetInstall "AVAST.AvastFreeAntivirus" "Avast Free Antivirus"
exit /b

:WG_Fallback_AVAST.AvastFreeAntivirus
!Fetch! "https://bits.avcdn.net/product/antivirus/win/avast_free_antivirus_setup_online.exe" -OutFile "%P_Dir%\avast.exe"
if !errorlevel! EQU 0 (start "" "%P_Dir%\avast.exe" & echo     [+] Launched) else (echo     [-] Failed)
goto :EOF

:Opt_61
echo     [Discord] -- winget always installs latest
call :WingetInstall "Discord.Discord" "Discord"
exit /b

:WG_Fallback_Discord.Discord
!Fetch! "https://discord.com/api/download/distributions/app/installers/latest?channel=stable&platform=win&arch=x64" -OutFile "%P_Dir%\discord.exe"
if !errorlevel! EQU 0 (start "" "%P_Dir%\discord.exe" & echo     [+] Launched) else (echo     [-] Failed)
goto :EOF

:Opt_62
echo     [Steam] -- winget always installs latest
call :WingetInstall "Valve.Steam" "Steam"
exit /b

:WG_Fallback_Valve.Steam
!Fetch! "https://cdn.akamai.steamstatic.com/client/installer/SteamSetup.exe" -OutFile "%P_Dir%\steam.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\steam.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: DEPLOYMENT RUNTIMES
:: ============================================================================

:Opt_41
echo     [Adobe AIR] -- direct download
set "W=04_AdobeAIR.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
!Fetch! "https://airsdk.harman.com/assets/downloads/51.3.3.1/AdobeAIR.exe" -OutFile "%F_Dir%\air.exe"
if !errorlevel! EQU 0 (start /wait "" "%F_Dir%\air.exe" -silent & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_42
echo     [XNA Framework] -- direct download
!Fetch! "https://download.microsoft.com/download/A/C/2/AC2F0A7C-5917-4588-89D0-7F0B3D2EB0A2/XNA%20Game%20Studio%204.0%20Refresh.vsix" -OutFile "%F_Dir%\xnafx40_redist.msi"
if !errorlevel! EQU 0 (msiexec /i "%F_Dir%\xnafx40_redist.msi" /qn & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_43
echo     [OpenAL] -- direct download
!Fetch! "https://openal.org/downloads/oalinst.zip" -OutFile "%F_Dir%\openal.zip"
if !errorlevel! EQU 0 (
    mkdir "%F_Dir%\OpenAL" 2>nul
    powershell -Command "Expand-Archive -Path '%F_Dir%\openal.zip' -DestinationPath '%F_Dir%\OpenAL' -Force"
    if exist "%F_Dir%\OpenAL\oalinst.exe" start /wait "" "%F_Dir%\OpenAL\oalinst.exe" /S
    del /f /q "%F_Dir%\openal.zip" 2>nul
    echo     [+] Installed
) else (echo     [-] Failed)
exit /b

:Opt_44
echo     [DirectX Legacy] -- Microsoft stable URL
set "W=06_DirectX.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
!Fetch! "https://download.microsoft.com/download/8/4/A/84A35BF1-DAFE-438A-A304-AD17EB294A39/directx_Jun2010_redist.exe" -OutFile "%F_Dir%\dxsetup.exe"
if !errorlevel! EQU 0 (
    mkdir "%F_Dir%\DX" 2>nul
    "%F_Dir%\dxsetup.exe" /Q /T:"%F_Dir%\DX"
    start /wait "" "%F_Dir%\DX\DXSETUP.exe" /silent
    echo     [+] Installed
) else (echo     [-] Failed)
exit /b

:Opt_45
echo     [Visual C++ AIO] -- GitHub latest release via API
set "W=07_VisualCppRedist.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd & exit /b)
:: abbodi1406 keeps a stable latest asset name: VisualCppRedist_AIO_x86_x64.exe
call :GHLatest "abbodi1406/vcredist" "VisualCppRedist_AIO_x86_x64.exe" "%F_Dir%\vcredist_aio.exe"
if exist "%F_Dir%\vcredist_aio.exe" (
    start /wait "" "%F_Dir%\vcredist_aio.exe" /y
    echo     [+] Visual C++ AIO installed
) else (
    echo     [-] Auto-download failed. Manual URL:
    echo     [!] https://github.com/abbodi1406/vcredist/releases/latest
)
exit /b

:Opt_46
echo     [NVIDIA PhysX] -- winget always installs latest
call :WingetInstall "Nvidia.PhysX" "NVIDIA PhysX"
exit /b

:WG_Fallback_Nvidia.PhysX
!Fetch! "https://us.download.nvidia.com/Windows/9.19.0218/PhysX-9.19.0218-SystemSoftware.exe" -OutFile "%F_Dir%\physx.exe"
if !errorlevel! EQU 0 (start /wait "" "%F_Dir%\physx.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_52
echo     [Java JRE 8 x86] -- winget always installs latest
call :WingetInstall "Oracle.JavaRuntimeEnvironment" "Java JRE (x64)"
echo     [!] Note: winget installs x64 JRE. For x86 see Oracle download portal.
exit /b

:WG_Fallback_Oracle.JavaRuntimeEnvironment
!Fetch! "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=252146_89d678f2b01e4f78be0b3b3fb29f80a4" -OutFile "%F_Dir%\jre8_x86.exe"
if !errorlevel! EQU 0 (start /wait "" "%F_Dir%\jre8_x86.exe" /s & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_53
echo     [Java JRE 8 x64] -- winget always installs latest
call :WingetInstall "Oracle.JavaRuntimeEnvironment" "Java JRE (x64)"
exit /b

:: ============================================================================
:: FORENSIC SUITES
:: ============================================================================

:Opt_151
echo     [KAPE Forensic] -- GitHub latest release via API
call :GHLatest "EricZimmerman/KapeFiles" "kape.zip" "%P_Dir%\kape.zip"
if exist "%P_Dir%\kape.zip" (call :UnpackPayload "kape.zip" "KAPE") else (echo     [-] Failed)
exit /b

:Opt_152
echo     [NirLauncher] -- stable vendor URL (always updated)
!Fetch! "https://www.nirsoft.net/utils/nirlauncher.zip" -OutFile "%P_Dir%\nirlauncher.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "nirlauncher.zip" "NirLauncher") else (echo     [-] Failed)
exit /b

:: ============================================================================
:: PAGE 2 - OFFICE AND PRODUCTIVITY
:: ============================================================================

:Opt_201
echo     [LibreOffice] -- winget always installs latest (340MB)
call :WingetInstall "TheDocumentFoundation.LibreOffice" "LibreOffice"
exit /b

:WG_Fallback_TheDocumentFoundation.LibreOffice
:: LibreOffice publishes a stable latest download URL
!Fetch! "https://download.documentfoundation.org/libreoffice/stable/latest/win/x86_64/LibreOffice_latest_Win_x86-64.msi" -OutFile "%P_Dir%\libreoffice.msi"
if !errorlevel! EQU 0 (msiexec /i "%P_Dir%\libreoffice.msi" /qn & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_202
echo     [SumatraPDF] -- winget always installs latest
call :WingetInstall "SumatraPDF.SumatraPDF" "SumatraPDF"
exit /b

:WG_Fallback_SumatraPDF.SumatraPDF
:: GitHub releases/latest/download - SumatraPDF keeps stable asset name
!Fetch! "https://github.com/sumatrapdfreader/sumatrapdf/releases/latest/download/SumatraPDF-64.zip" -OutFile "%P_Dir%\sumatra.zip"
if !errorlevel! EQU 0 (call :UnpackPayload "sumatra.zip" "SumatraPDF") else (echo     [-] Failed)
goto :EOF

:Opt_203
echo     [Foxit Reader] -- winget always installs latest
call :WingetInstall "Foxit.FoxitReader" "Foxit PDF Reader"
exit /b

:WG_Fallback_Foxit.FoxitReader
!Fetch! "https://cdn01.foxitsoftware.com/product/reader/desktop/win/latest/FoxitPDFReader_Setup_Std.msi" -OutFile "%P_Dir%\foxit.msi"
if !errorlevel! EQU 0 (msiexec /i "%P_Dir%\foxit.msi" /quiet & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_204
echo     [Notepad3] -- GitHub latest release redirect
!Fetch! "https://github.com/rizonesoft/Notepad3/releases/latest/download/Notepad3_x64_Setup.exe" -OutFile "%P_Dir%\notepad3.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\notepad3.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_205
echo     [WPS Office] -- winget always installs latest (205MB)
call :WingetInstall "Kingsoft.WPSOffice" "WPS Office"
exit /b

:WG_Fallback_Kingsoft.WPSOffice
!Fetch! "https://wps-android.oss-cn-shanghai.aliyuncs.com/wps/download/ep/WPSOffice_Free.exe" -OutFile "%P_Dir%\wpsoffice.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\wpsoffice.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: PAGE 2 - MEDIA PRODUCTION
:: ============================================================================

:Opt_210
echo     [OBS Studio] -- winget always installs latest (130MB)
call :WingetInstall "OBSProject.OBSStudio" "OBS Studio"
exit /b

:WG_Fallback_OBSProject.OBSStudio
:: GitHub latest redirect - OBS keeps stable asset name
!Fetch! "https://github.com/obsproject/obs-studio/releases/latest/download/OBS-Studio-Windows-Installer.exe" -OutFile "%P_Dir%\obs.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\obs.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_211
echo     [Handbrake] -- winget always installs latest
call :WingetInstall "HandBrake.HandBrake" "HandBrake"
exit /b

:WG_Fallback_HandBrake.HandBrake
:: GitHub latest redirect - HandBrake keeps stable asset name
!Fetch! "https://github.com/HandBrake/HandBrake/releases/latest/download/HandBrake-x86_64-Win_GUI.exe" -OutFile "%P_Dir%\handbrake.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\handbrake.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_212
echo     [Audacity] -- winget always installs latest
call :WingetInstall "Audacity.Audacity" "Audacity"
exit /b

:WG_Fallback_Audacity.Audacity
:: GitHub latest redirect
!Fetch! "https://github.com/audacity/audacity/releases/latest/download/audacity-win-x64.exe" -OutFile "%P_Dir%\audacity.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\audacity.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_213
echo     [VLC] -- winget always installs latest
call :WingetInstall "VideoLAN.VLC" "VLC Media Player"
exit /b

:WG_Fallback_VideoLAN.VLC
:: VideoLAN publishes a stable latest x64 URL
!Fetch! "https://get.videolan.org/vlc/last/win64/" -OutFile "%P_Dir%\vlc_redirect.html"
powershell -Command ^
  "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
  "$ProgressPreference='SilentlyContinue';" ^
  "$html=Get-Content '%P_Dir%\vlc_redirect.html' -Raw;" ^
  "$match=[regex]::Match($html,'href=\"(vlc-[\d\.]+-win64\.exe)\"');" ^
  "if($match.Success){Invoke-WebRequest ('https://get.videolan.org/vlc/last/win64/'+$match.Groups[1].Value) -OutFile '%P_Dir%\vlc.exe'}"
del /f /q "%P_Dir%\vlc_redirect.html" 2>nul
if exist "%P_Dir%\vlc.exe" (start /wait "" "%P_Dir%\vlc.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_214
echo     [Shotcut] -- winget always installs latest
call :WingetInstall "Meltytech.Shotcut" "Shotcut"
exit /b

:WG_Fallback_Meltytech.Shotcut
:: GitHub latest redirect - Shotcut keeps stable asset name
!Fetch! "https://github.com/mltframework/shotcut/releases/latest/download/shotcut-win64.exe" -OutFile "%P_Dir%\shotcut.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\shotcut.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: PAGE 2 - DEVELOPER TOOLS
:: ============================================================================

:Opt_220
echo     [VS Code] -- winget always installs latest
call :WingetInstall "Microsoft.VisualStudioCode" "Visual Studio Code"
exit /b

:WG_Fallback_Microsoft.VisualStudioCode
:: Microsoft publishes a stable latest URL
!Fetch! "https://update.code.visualstudio.com/latest/win32-x64-user/stable" -OutFile "%P_Dir%\vscode.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\vscode.exe" /verysilent & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_221
echo     [Notepad++] -- winget always installs latest
call :WingetInstall "Notepad++.Notepad++" "Notepad++"
exit /b

:WG_Fallback_Notepad++.Notepad++
:: GitHub latest redirect - npp keeps stable asset pattern
call :GHLatest "notepad-plus-plus/notepad-plus-plus" "Installer.x64.exe" "%P_Dir%\npp.exe"
if exist "%P_Dir%\npp.exe" (start /wait "" "%P_Dir%\npp.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_222
echo     [Git] -- winget always installs latest
call :WingetInstall "Git.Git" "Git for Windows"
exit /b

:WG_Fallback_Git.Git
:: GitHub latest redirect - Git keeps stable asset name
call :GHLatest "git-for-windows/git" "64-bit.exe" "%P_Dir%\git.exe"
if exist "%P_Dir%\git.exe" (start /wait "" "%P_Dir%\git.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_223
echo     [Python 3] -- winget always installs latest
call :WingetInstall "Python.Python.3" "Python 3"
exit /b

:WG_Fallback_Python.Python.3
:: Python.org stable URL - always latest 3.x
!Fetch! "https://www.python.org/ftp/python/latest/python-latest-amd64.exe" -OutFile "%P_Dir%\python.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\python.exe" /quiet InstallAllUsers=1 PrependPath=1 & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_224
echo     [WinMerge] -- winget always installs latest
call :WingetInstall "WinMerge.WinMerge" "WinMerge"
exit /b

:WG_Fallback_WinMerge.WinMerge
:: GitHub latest redirect
!Fetch! "https://github.com/WinMerge/winmerge/releases/latest/download/WinMerge-x64-Setup.exe" -OutFile "%P_Dir%\winmerge.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\winmerge.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: PAGE 2 - GAMING AND SOCIAL
:: ============================================================================

:Opt_230
echo     [GOG Galaxy] -- winget always installs latest
call :WingetInstall "GOG.Galaxy" "GOG Galaxy"
exit /b

:WG_Fallback_GOG.Galaxy
!Fetch! "https://webinstallers.gog-statics.com/download/GOG_Galaxy_2.0.exe" -OutFile "%P_Dir%\gog.exe"
if !errorlevel! EQU 0 (start "" "%P_Dir%\gog.exe" & echo     [+] Launched) else (echo     [-] Failed)
goto :EOF

:Opt_231
echo     [Epic Games] -- winget always installs latest
call :WingetInstall "EpicGames.EpicGamesLauncher" "Epic Games Launcher"
exit /b

:WG_Fallback_EpicGames.EpicGamesLauncher
!Fetch! "https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/installer/download/EpicGamesLauncherInstaller.msi" -OutFile "%P_Dir%\epic.msi"
if !errorlevel! EQU 0 (msiexec /i "%P_Dir%\epic.msi" /qn & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_232
echo     [Zoom] -- winget always installs latest
call :WingetInstall "Zoom.Zoom" "Zoom"
exit /b

:WG_Fallback_Zoom.Zoom
!Fetch! "https://zoom.us/client/latest/ZoomInstallerFull.exe" -OutFile "%P_Dir%\zoom.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\zoom.exe" /quiet & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_233
echo     [Skype] -- winget always installs latest
call :WingetInstall "Microsoft.Skype" "Skype"
exit /b

:WG_Fallback_Microsoft.Skype
!Fetch! "https://go.skype.com/windows.desktop.download" -OutFile "%P_Dir%\skype.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\skype.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_234
echo     [WhatsApp] -- winget always installs latest
call :WingetInstall "9NKSQGP7F2NH" "WhatsApp Desktop"
exit /b

:WG_Fallback_9NKSQGP7F2NH
!Fetch! "https://web.whatsapp.com/desktop/windows/release/x64/WhatsAppSetup.exe" -OutFile "%P_Dir%\whatsapp.exe"
if !errorlevel! EQU 0 (start "" "%P_Dir%\whatsapp.exe" & echo     [+] Launched) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: PAGE 2 - NETWORK AND SERVER
:: ============================================================================

:Opt_240
echo     [Wireshark] -- winget always installs latest
call :WingetInstall "WiresharkFoundation.Wireshark" "Wireshark"
exit /b

:WG_Fallback_WiresharkFoundation.Wireshark
:: Wireshark stable latest x64 URL
!Fetch! "https://www.wireshark.org/download/win64/all-versions/Wireshark-latest-x64.exe" -OutFile "%P_Dir%\wireshark.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\wireshark.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_241
echo     [Nmap] -- winget always installs latest
call :WingetInstall "Insecure.Nmap" "Nmap"
exit /b

:WG_Fallback_Insecure.Nmap
call :GHLatest "nmap/nmap" "setup.exe" "%P_Dir%\nmap.exe"
if exist "%P_Dir%\nmap.exe" (start /wait "" "%P_Dir%\nmap.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_242
echo     [PuTTY] -- winget always installs latest
call :WingetInstall "PuTTY.PuTTY" "PuTTY"
exit /b

:WG_Fallback_PuTTY.PuTTY
:: PuTTY stable latest URL
!Fetch! "https://the.earth.li/~sgtatham/putty/latest/w64/putty-64bit-installer.msi" -OutFile "%P_Dir%\putty.msi"
if !errorlevel! EQU 0 (msiexec /i "%P_Dir%\putty.msi" /quiet & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_243
echo     [FileZilla] -- winget always installs latest
call :WingetInstall "TimKosse.FileZilla.Client" "FileZilla"
exit /b

:WG_Fallback_TimKosse.FileZilla.Client
call :GHLatest "filezilla-project/filezilla" "win64-setup.exe" "%P_Dir%\filezilla.exe"
if exist "%P_Dir%\filezilla.exe" (start /wait "" "%P_Dir%\filezilla.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_244
echo     [Advanced IP Scanner] -- winget always installs latest
call :WingetInstall "Famatech.AdvancedIPScanner" "Advanced IP Scanner"
exit /b

:: ============================================================================
:: PAGE 2 - SECURITY AND PRIVACY
:: ============================================================================

:Opt_250
echo     [Malwarebytes] -- winget always installs latest
call :WingetInstall "Malwarebytes.Malwarebytes" "Malwarebytes"
exit /b

:WG_Fallback_Malwarebytes.Malwarebytes
!Fetch! "https://data-cdn.mbamupdates.com/web/mb5-setup-consumer/MBSetup.exe" -OutFile "%P_Dir%\malwarebytes.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\malwarebytes.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_251
echo     [Bitdefender] -- direct download
!Fetch! "https://download.bitdefender.com/windows/bp/agent/en/bitdefender_online.exe" -OutFile "%P_Dir%\bitdefender.exe"
if !errorlevel! EQU 0 (start "" "%P_Dir%\bitdefender.exe" & echo     [+] Launched) else (echo     [-] Failed)
exit /b

:Opt_252
echo     [Kaspersky KVRT] -- stable vendor URL (always updated)
!Fetch! "https://devbuilds.s.kaspersky-labs.com/devbuilds/KVRT/latest/full/KVRT.exe" -OutFile "%P_Dir%\kvrt.exe"
if !errorlevel! EQU 0 (echo     [+] Ready) else (echo     [-] Failed)
exit /b

:Opt_253
echo     [GlassWire] -- winget always installs latest
call :WingetInstall "GlassWire.GlassWire" "GlassWire"
exit /b

:WG_Fallback_GlassWire.GlassWire
!Fetch! "https://download.glasswire.com/GlassWireSetup.exe" -OutFile "%P_Dir%\glasswire.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\glasswire.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_254
echo     [VeraCrypt] -- winget always installs latest
call :WingetInstall "IDRIX.VeraCrypt" "VeraCrypt"
exit /b

:WG_Fallback_IDRIX.VeraCrypt
:: GitHub latest redirect - VeraCrypt keeps stable asset name
!Fetch! "https://github.com/veracrypt/VeraCrypt/releases/latest/download/VeraCrypt%20Setup.exe" -OutFile "%P_Dir%\veracrypt.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\veracrypt.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: PAGE 2 - ARCHIVE AND ISO
:: ============================================================================

:Opt_260
echo     [PowerISO] -- winget always installs latest
call :WingetInstall "PowerISO.PowerISO" "PowerISO"
exit /b

:WG_Fallback_PowerISO.PowerISO
!Fetch! "https://www.poweriso.com/PowerISO8-x64.exe" -OutFile "%P_Dir%\poweriso.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\poweriso.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_261
echo     [Rufus Latest] -- GitHub latest release redirect (always latest)
!Fetch! "https://github.com/pbatard/rufus/releases/latest/download/rufus.exe" -OutFile "%P_Dir%\rufus_latest.exe"
if !errorlevel! EQU 0 (echo     [+] Ready - latest Rufus) else (echo     [-] Failed)
exit /b

:Opt_262
echo     [ImgBurn] -- winget always installs latest
call :WingetInstall "LIGHTNING.UK.ImgBurn" "ImgBurn"
exit /b

:WG_Fallback_LIGHTNING.UK.ImgBurn
!Fetch! "https://www.imgburn.com/SetupImgBurn_2.5.8.0.exe" -OutFile "%P_Dir%\imgburn.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\imgburn.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:Opt_263
echo     [AnyBurn] -- direct download (stable vendor URL)
!Fetch! "https://www.anyburn.com/anyburn_setup.exe" -OutFile "%P_Dir%\anyburn.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\anyburn.exe" /S & echo     [+] Installed) else (echo     [-] Failed)
exit /b

:Opt_264
echo     [BurnAware] -- winget always installs latest
call :WingetInstall "Burnaware.BurnAwareFree" "BurnAware Free"
exit /b

:WG_Fallback_Burnaware.BurnAwareFree
!Fetch! "https://www.burnaware.com/download/BurnAwareFree.exe" -OutFile "%P_Dir%\burnaware.exe"
if !errorlevel! EQU 0 (start /wait "" "%P_Dir%\burnaware.exe" /VERYSILENT & echo     [+] Installed) else (echo     [-] Failed)
goto :EOF

:: ============================================================================
:: LEGACY SUPPORT
:: ============================================================================

:Opt_270
set "W=14_Net_Desktop_v5_x64.cmd" & if "%Arch%"=="x86" set "W=15_Net_Desktop_v5_x86.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd)
exit /b

:Opt_271
set "W=16_Net_Desktop_v6_x64.cmd" & if "%Arch%"=="x86" set "W=17_Net_Desktop_v6_x86.cmd"
if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd)
exit /b

:Opt_280
set "W=02_OldCalcWin10.cmd" & if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd)
exit /b

:Opt_281
set "W=32_startback.cmd" & if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd)
exit /b

:Opt_282
set "W=09_iobit_unlocker.cmd" & if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd)
exit /b

:Opt_291
set "W=13_NDP481.cmd" & if exist "%Src_Dir%\%W%" (pushd "%Src_Dir%" & call "%W%" & popd)
exit /b

:: ============================================================================
:: SAVE / LOAD PROFILES
:: ============================================================================

:SaveProfile
set /p "cq=Enter tool IDs (space-separated): "
if defined cq (
    echo %cq% > "%F_Dir%\Profile.txt"
    echo     [+] Profile saved
    timeout /t 1 >nul
)
goto :MainMenu

:LoadProfile
if exist "%F_Dir%\Profile.txt" (
    set /p opts=<"%F_Dir%\Profile.txt"
    echo     [+] Profile loaded: !opts!
    timeout /t 1 >nul
    goto :RunSelectionLoop
) else (
    echo     [-] No profile found
    timeout /t 2 >nul
)
goto :MainMenu
